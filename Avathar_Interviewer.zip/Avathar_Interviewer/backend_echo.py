from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import torchaudio as ta
import torch
from chatterbox.tts_turbo import ChatterboxTurboTTS
import io
import base64
import tempfile
import os
import random
import re
import glob

app = Flask(__name__)
CORS(app)


print("Loading ChatterboxTurbo model...")
torch.cuda.empty_cache()
model = ChatterboxTurboTTS.from_pretrained(device="cuda")
print("Model loaded successfully!")

# Voice configuration
VOICE_DIR = "/home/sujith_ubuntu/chatterboxTurbo/work/voices"
DEFAULT_VOICE = "test01_20s.wav"

# Cache for available voices to avoid rescanning on every request
voices_cache = None
voices_cache_time = 0
CACHE_EXPIRY = 300  # Cache for 5 minutes
import time

# Initialize cache at startup (clear any stale cache)
def init_voices_cache():
    """Initialize voices cache at startup"""
    global voices_cache, voices_cache_time
    voices_cache = None
    voices_cache_time = 0
    print(f"Voice cache initialized. Voice directory: {VOICE_DIR}")

init_voices_cache()

def get_available_voices():
    """Get list of available voice files (cached to avoid redundant disk scans)"""
    global voices_cache, voices_cache_time
    
    # Return cached voices if still valid
    current_time = time.time()
    if voices_cache is not None and (current_time - voices_cache_time) < CACHE_EXPIRY:
        print(f"Returning cached voices: {list(voices_cache.keys())}")
        return voices_cache
    
    try:
        print(f"Scanning voice directory: {VOICE_DIR}")
        # Support .wav, .mp3, and .m4a files
        wav_files = glob.glob(os.path.join(VOICE_DIR, "*.wav"))
        mp3_files = glob.glob(os.path.join(VOICE_DIR, "*.mp3"))
        m4a_files = glob.glob(os.path.join(VOICE_DIR, "*.m4a"))
        all_files = wav_files + mp3_files + m4a_files
        
        print(f"Found {len(wav_files)} .wav files, {len(mp3_files)} .mp3 files, and {len(m4a_files)} .m4a files")
        
        voices = {}
        for voice_file in all_files:
            filename = os.path.basename(voice_file)
            # Skip temporary zone files
            if ":Zone" in filename:
                print(f"Skipping zone file: {filename}")
                continue
            # Create a friendly name from filename
            voice_name = filename.replace(".wav", "").replace(".mp3", "").replace(".m4a", "").replace("_", " ").title()
            is_default = filename == DEFAULT_VOICE
            voices[filename] = {
                "name": voice_name,
                "path": voice_file,
                "is_default": is_default
            }
            print(f"Added voice: {filename} -> {voice_name} (default: {is_default})")
        
        voices_cache = voices
        voices_cache_time = current_time
        print(f"Voice cache updated. Total voices: {len(voices)}")
        return voices
    except Exception as e:
        print(f"Error getting voices: {str(e)}")
        print(f"Voice directory exists: {os.path.exists(VOICE_DIR)}")
        if os.path.exists(VOICE_DIR):
            print(f"Files in directory: {os.listdir(VOICE_DIR)}")
        
        default_voices = {DEFAULT_VOICE: {
            "name": "Default Voice",
            "path": os.path.join(VOICE_DIR, DEFAULT_VOICE),
            "is_default": True
        }}
        voices_cache = default_voices
        voices_cache_time = current_time
        return default_voices

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "ok", "message": "ChatterboxTurbo Echo System Ready"})

@app.route('/', methods=['GET'])
def serve_frontend():
    """Serve the frontend HTML"""
    try:
        with open(os.path.join(os.path.dirname(__file__), 'front.html'), 'r') as f:
            return f.read()
    except Exception as e:
        return jsonify({"error": "Could not load frontend: " + str(e)}), 500

@app.route('/voices', methods=['GET'])
def get_voices():
    """Get list of available voices"""
    voices = get_available_voices()
    # Return in a format suitable for frontend
    voice_list = [
        {
            "filename": filename,
            "name": voice_info["name"],
            "is_default": voice_info["is_default"]
        }
        for filename, voice_info in voices.items()
    ]
    return jsonify({"success": True, "voices": voice_list})


PARALINGUISTIC_TAGS = [
    "[clear throat]",
    "[sigh]",
    "[shush]",
    "[cough]",
    "[groan]",
    "[sniff]",
    "[gasp]",
    "[chuckle]",
    "[laugh]"
]

def insert_paralinguistic_tags(text, words_per_segment=8):
    """
    Insert random paralinguistic tags after every few words (simulating sentence segments).
    This works better with STT output that may not have proper punctuation.
    
    Args:
        text (str): Input text to process
        words_per_segment (int): Number of words after which to insert a tag (default: 8 words)
    
    Returns:
        str: Text with randomly inserted paralinguistic tags between square brackets
    """
    words = text.split()
    
    if len(words) < words_per_segment:
        # Not enough words, just return original text
        return text
    
    result = []
    for i, word in enumerate(words):
        result.append(word)
        
        # Add a tag after every N words (but not after the last word)
        if (i + 1) % words_per_segment == 0 and i < len(words) - 1:
            tag = random.choice(PARALINGUISTIC_TAGS)
            result.append(tag)
    
    return ' '.join(result)

def split_text(text, max_length=250):
    """Split text into chunks of max_length characters"""
    words = text.split()
    chunks = []
    current_chunk = []

    for word in words:
        # Check if adding this word exceeds the max length
        if len(' '.join(current_chunk + [word])) <= max_length:
            current_chunk.append(word)
        else:
            # If it exceeds, add current chunk to chunks and start a new chunk
            if current_chunk:
                chunks.append(' '.join(current_chunk))
            current_chunk = [word]
    
    # Don't forget to add the last chunk
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    
    return chunks

@app.route('/echo', methods=['POST'])
def echo():
    try:
        data = request.json
        text = data.get('text', '')
        voice = data.get('voice', DEFAULT_VOICE)
        
        if not text:
            return jsonify({"error": "No text provided"}), 400
        
        # Validate and get voice path
        available_voices = get_available_voices()
        if voice not in available_voices:
            voice = DEFAULT_VOICE
            print(f"Voice '{voice}' not found, using default voice")
        
        voice_path = available_voices[voice]["path"]
        print(f"Using voice: {voice} ({available_voices[voice]['name']})")
        print(f"Generating speech for: {text}")
        
        # Insert paralinguistic tags randomly after every 8 words
        #text_with_tags = insert_paralinguistic_tags(text, words_per_segment=8)
        text_with_tags = text
        print(f"Text with paralinguistic tags: {text_with_tags}")
        
        # Split text into chunks if longer than 250 characters
        chunks = split_text(text_with_tags, max_length=250)
        print(f"Split into {len(chunks)} chunks")
        
        # List to hold individual audio clips
        audio_clips = []
        
        try:
            # Disable gradients for inference to save memory
            with torch.no_grad():
                # Generate audio for each chunk
                for i, chunk in enumerate(chunks):
                    print(f"Generating audio for chunk {i+1}/{len(chunks)}: {chunk[:50]}...")
                    wav = model.generate(
                        chunk, 
                        audio_prompt_path=voice_path
                    )
                    audio_clips.append(wav)
                    # Clear CUDA cache after each chunk to free memory immediately
                    #torch.cuda.empty_cache()
            
            # Concatenate all audio clips
            final_audio = torch.cat(audio_clips, dim=-1)
            
            # Clear the individual clips to free memory
            audio_clips.clear()
            #torch.cuda.empty_cache()
        except Exception as e:
            # Clean up if error occurs during generation
            audio_clips.clear()
            #torch.cuda.empty_cache()
            raise e
        
        # Save to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp_file:
            ta.save(tmp_file.name, final_audio, model.sr)
            tmp_filename = tmp_file.name
        
        # Read the file and convert to base64
        try:
            with open(tmp_filename, 'rb') as audio_file:
                audio_data = audio_file.read()
                audio_base64 = base64.b64encode(audio_data).decode('utf-8')
        finally:
            # Always clean up temp file, even if read fails
            if os.path.exists(tmp_filename):
                os.unlink(tmp_filename)
        
        # Final cleanup - release tensor references and clear CUDA memory
        final_audio = None
        #torch.cuda.empty_cache()
        
        return jsonify({
            "success": True,
            "audio": audio_base64,
            "text": text,
            "text_with_tags": text_with_tags
        })
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)