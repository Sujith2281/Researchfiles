# from django.urls import path
# from .views import InterviewPageView


# urlpatterns = [
#         path('',InterviewPageView.as_view(),name = "interview page")
# ]


from django.urls import path

from .views import (
    RootRedirectView,
    StartInterviewView,
    SendMessageView,
    TranscribeAudioView,
    EndInterviewView,
    SessionStatusView,
)

urlpatterns = [
    # Root
    path("", RootRedirectView.as_view(), name="root"),

    # Interview APIs
    path("api/start-interview", StartInterviewView.as_view(), name="start-interview"),
    path("api/send-message", SendMessageView.as_view(), name="send-message"),
    path("api/transcribe", TranscribeAudioView.as_view(), name="transcribe-audio"),
    path("api/end-interview", EndInterviewView.as_view(), name="end-interview"),
    path(
        "api/session-status/<str:session_id>",
        SessionStatusView.as_view(),
        name="session-status",
    ),
]
