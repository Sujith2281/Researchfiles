// ============= STATE =============
let sessionId = null;
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let isAISpeaking = false;
let isProcessing = false;
let silenceTimer = null;
let initialSilenceTimer = null;
let hasUserStartedSpeaking = false;
let interviewEnded = false;

// Timing constants
const INITIAL_SILENCE_THRESHOLD = 5000; // 5 seconds before user starts speaking
const SILENCE_THRESHOLD = 4000; // 5 seconds of continuous silence after speaking
const MIN_RECORDING_TIME = 500; // Minimum recording time

// ============= DOM ELEMENTS =============
const startBtn = document.getElementById('startBtn');
const endBtn = document.getElementById('endBtn');
const chatContainer = document.getElementById('chatContainer');
const userVideo = document.getElementById('userVideo');
const aiAudio = document.getElementById('aiAudio');
const statusIndicator = document.getElementById('statusIndicator');
const recordingStatus = document.getElementById('recordingStatus');

// ============= INITIALIZATION =============
let audioStream = null;

async function initializeMedia() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: true, 
            audio: true 
        });
        userVideo.srcObject = stream;
        
        // Get separate audio stream for recording
        audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        return stream;
    } catch (err) {
        alert('Camera and microphone access required for interview');
        throw err;
    }
}

// ============= CHAT UI =============
function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    messageDiv.textContent = text;
    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

function setStatus(text, type = 'info') {
    statusIndicator.textContent = text;
    statusIndicator.className = `status-indicator ${type}`;
}

function setRecordingStatus(text) {
    recordingStatus.textContent = text;
}

// ============= AUDIO PLAYBACK =============
function playAudio(base64Audio) {
    return new Promise((resolve, reject) => {
        if (!base64Audio) {
            resolve();
            return;
        }
        
        isAISpeaking = true;
        setStatus('AI Speaking...', 'speaking');
        
        // Animate AI avatar while speaking
        const aiAvatar = document.getElementById('aiAvatar');
        aiAvatar.classList.add('speaking');
        
        const audioBlob = base64ToBlob(base64Audio, 'audio/wav');
        const audioUrl = URL.createObjectURL(audioBlob);
        
        aiAudio.src = audioUrl;
        aiAudio.onended = () => {
            isAISpeaking = false;
            aiAvatar.classList.remove('speaking');
            URL.revokeObjectURL(audioUrl);
            resolve();
        };
        aiAudio.onerror = reject;
        aiAudio.play();
    });
}

function base64ToBlob(base64, mimeType) {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
}

// ============= RECORDING WITH VAD =============
function getSupportedMimeType() {
    const types = [
        'audio/webm',
        'audio/webm;codecs=opus',
        'audio/ogg;codecs=opus',
        'audio/mp4',
        'audio/wav'
    ];
    
    for (const type of types) {
        if (MediaRecorder.isTypeSupported(type)) {
            return type;
        }
    }
    return ''; // Use default
}

async function startListening() {
    if (isAISpeaking || isProcessing || interviewEnded) return;
    
    if (!audioStream) return;
    
    console.log('\n🎙️ === STARTING LISTENING SESSION ===');
    
    audioChunks = [];
    hasUserStartedSpeaking = false;
    
    const mimeType = getSupportedMimeType();
    const options = mimeType ? { mimeType } : {};
    mediaRecorder = new MediaRecorder(audioStream, options);
    
    mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
            audioChunks.push(event.data);
        }
    };
    
    mediaRecorder.onstop = async () => {
        console.log('📼 MediaRecorder stopped, audio chunks:', audioChunks.length);
        if (audioChunks.length > 0) {
            await processRecording();
        }
    };
    
    mediaRecorder.start(100);
    isRecording = true;
    setStatus('Listening...', 'listening');
    setRecordingStatus('🎤 Listening...');
    
    console.log('⏱️ Initial silence timer: 5 seconds');
    initialSilenceTimer = setTimeout(() => {
        if (isRecording && !hasUserStartedSpeaking) {
            console.log('⏰ Initial silence timeout - no speech detected');
            stopListening();
        }
    }, INITIAL_SILENCE_THRESHOLD);
    
    monitorAudioLevels();
}

function monitorAudioLevels() {
    const audioContext = new AudioContext();
    const analyser = audioContext.createAnalyser();
    const microphone = audioContext.createMediaStreamSource(audioStream);
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    
    microphone.connect(analyser);
    analyser.fftSize = 512;
    
    const SPEECH_THRESHOLD = 10; // Lowered for better detection
    let localSilenceTimer = null;
    let frameCount = 0;
    let lastLogTime = Date.now();
    
    console.log('=== VAD MONITORING STARTED ===');
    console.log('Speech threshold:', SPEECH_THRESHOLD);
    console.log('Silence threshold:', SILENCE_THRESHOLD, 'ms');
    
    function checkAudioLevel() {
        if (!isRecording) {
            console.log('=== VAD MONITORING STOPPED ===');
            audioContext.close();
            if (localSilenceTimer) clearTimeout(localSilenceTimer);
            return;
        }
        
        analyser.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        frameCount++;
        
        // Log every 60 frames (~1 second)
        if (frameCount % 60 === 0) {
            const now = Date.now();
            console.log(`[${frameCount}] Audio level: ${average.toFixed(2)} | Timer active: ${localSilenceTimer !== null} | Speaking: ${hasUserStartedSpeaking}`);
            lastLogTime = now;
        }
        
        if (average > SPEECH_THRESHOLD) {
            // Speech detected
            if (!hasUserStartedSpeaking) {
                hasUserStartedSpeaking = true;
                clearTimeout(initialSilenceTimer);
                setRecordingStatus('🎤 Recording...');
                console.log('✅ USER STARTED SPEAKING');
            }
            
            // Clear existing timer
            if (localSilenceTimer) {
                clearTimeout(localSilenceTimer);
                localSilenceTimer = null;
                console.log('🔄 SPEECH DETECTED - Timer cleared');
            }
        } else if (hasUserStartedSpeaking && !localSilenceTimer) {
            // Silence started - set timer ONCE
            console.log('🔇 SILENCE DETECTED - Starting 5 second timer...');
            localSilenceTimer = setTimeout(() => {
                console.log('⏰ TIMER FIRED - 5 seconds of silence reached');
                stopListening();
            }, SILENCE_THRESHOLD);
        }
        
        requestAnimationFrame(checkAudioLevel);
    }
    
    checkAudioLevel();
}

function stopListening() {
    console.log('🛑 STOP LISTENING CALLED');
    if (mediaRecorder && isRecording) {
        clearTimeout(silenceTimer);
        clearTimeout(initialSilenceTimer);
        mediaRecorder.stop();
        isRecording = false;
        setRecordingStatus('');
        console.log('✅ Recording stopped');
    }
}

async function processRecording() {
    if (isProcessing || interviewEnded) return;
    
    isProcessing = true;
    setStatus('Processing...', 'processing');
    console.log('\n🔄 === PROCESSING RECORDING ===');
    
    try {
        const mimeType = getSupportedMimeType() || 'audio/webm';
        const audioBlob = new Blob(audioChunks, { type: mimeType });
        console.log('📦 Audio blob size:', audioBlob.size, 'bytes');
        
        // Transcribe audio
        const formData = new FormData();
        formData.append('audio_file', audioBlob, 'recording.webm');
        
        console.log('📤 Sending to ASR...');
        const transcribeRes = await fetch('/interviewer/api/transcribe', {
            method: 'POST',
            body: formData
        });
        
        const transcribeData = await transcribeRes.json();
        console.log('📥 ASR Response:', transcribeData);
        
        if (!transcribeData.success || !transcribeData.text.trim()) {
            console.log('⚠️ No speech detected, restarting listening...');
            isProcessing = false;
            startListening();
            return;
        }
        
        const userText = transcribeData.text;
        console.log('💬 User said:', userText);
        addMessage(userText, 'user');
        
        // Send to AI
        console.log('🤖 Sending to AI...');
        const messageRes = await fetch('/interviewer/api/send-message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                session_id: sessionId,
                text: userText
            })
        });
        
        const messageData = await messageRes.json();
        console.log('🤖 AI Response received');
        
        if (messageData.success) {
            addMessage(messageData.text, 'ai');
            
            // Play AI audio
            console.log('🔊 Playing AI audio...');
            await playAudio(messageData.audio);
            console.log('✅ AI audio finished');
            
            if (messageData.interview_ended) {
                interviewEnded = true;
                setStatus('Interview Complete', 'complete');
                endBtn.disabled = false;
                console.log('🏁 Interview ended');
            } else {
                // Continue listening after AI finishes speaking
                isProcessing = false;
                startListening();
            }
        }
    } catch (err) {
        console.error('❌ Processing error:', err);
        setStatus('Error occurred', 'error');
    } finally {
        if (!interviewEnded) {
            isProcessing = false;
        }
    }
}

// ============= INTERVIEW CONTROL =============
startBtn.addEventListener('click', async () => {
    try {
        await initializeMedia();
        
        sessionId = 'session_' + Date.now();
        
        startBtn.disabled = true;
        setStatus('Starting interview...', 'processing');
        
        const res = await fetch('/interviewer/api/start-interview', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ session_id: sessionId })
        });
        
        const data = await res.json();
        
        if (data.success) {
            addMessage(data.text, 'ai');
            
            // Play greeting and start listening
            await playAudio(data.audio);
            
            endBtn.disabled = false;
            startListening();
        }
    } catch (err) {
        alert('Failed to start interview: ' + err.message);
        startBtn.disabled = false;
    }
});

endBtn.addEventListener('click', async () => {
    stopListening();
    interviewEnded = true;
    
    try {
        const res = await fetch('/interviewer/api/end-interview', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ session_id: sessionId })
        });
        
        const data = await res.json();
        
        if (data.success) {
            setStatus('Interview Ended', 'complete');
            console.log('Conversation History:', data.conversation_history);
            alert('Interview ended. Check console for conversation history.');
        }
    } catch (err) {
        console.error('End interview error:', err);
    }
    
    endBtn.disabled = true;
});
