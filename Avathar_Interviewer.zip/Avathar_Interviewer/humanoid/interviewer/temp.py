"""
Django Rest Framework Interview Application
Converted from FastAPI with Profiler + ASR + TTS
"""

import httpx
from django.shortcuts import redirect, render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser

from .AI_engine import AIInterviewer


# ================== CONFIG ==================
TTS_API_URL = "http://localhost:5000/echo"
ASR_API_URL = "https://speech.pranathiss.com/api/vad-speech-to-text/"
PROFILER_DATA_API_URL = "http://localhost:8000/parsed-data/"


# ================== IN-MEMORY SESSION STORE ==================
# ⚠️ DEV ONLY – use Redis/DB in prod
sessions: dict[str, dict] = {}


# ================== ROOT ==================

class RootRedirectView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        return render(request,"interviewer/interview_page.html")


# ================== START INTERVIEW ==================

class StartInterviewView(APIView):
    authentication_classes = []
    permission_classes = []

    async def post(self, request):
        session_id = request.data.get("session_id")

        if not session_id:
            return Response(
                {"error": "session_id required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # -------- FETCH PROFILER DATA --------
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                profiler_response = await client.get(PROFILER_DATA_API_URL)

            if profiler_response.status_code != 200:
                return Response(
                    {"error": "Profiler API failed"},
                    status=status.HTTP_502_BAD_GATEWAY
                )

            profiler_data = profiler_response.json()

            parsed_resume = profiler_data.get("parsed_resume")
            parsed_jd = profiler_data.get("parsed_jd")
            intention = profiler_data.get("intention")

            if not parsed_resume or not parsed_jd:
                return Response(
                    {"error": "Invalid profiler data"},
                    status=status.HTTP_400_BAD_REQUEST
                )

        except Exception as e:
            return Response(
                {"error": f"Profiler API error: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        # -------- CREATE INTERVIEWER --------
        try:
            interviewer = AIInterviewer(
                resume=parsed_resume,
                job_description=parsed_jd,
                intention=intention
            )
        except TypeError:
            interviewer = AIInterviewer(parsed_resume, parsed_jd)

        greeting = interviewer.start_interview()

        # -------- STORE SESSION --------
        sessions[session_id] = {
            "interviewer": interviewer,
            "is_processing": False
        }

        # -------- TTS --------
        audio = None
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                tts_response = await client.post(
                    TTS_API_URL,
                    json={"text": greeting}
                )
                audio = tts_response.json().get("audio")
        except Exception:
            pass

        return Response({
            "success": True,
            "text": greeting,
            "audio": audio,
            "interview_ended": False
        })



# ================== SEND MESSAGE ==================

class SendMessageView(APIView):
    authentication_classes = []
    permission_classes = []

    async def post(self, request):
        session_id = request.data.get("session_id")
        text = request.data.get("text")

        if not session_id or not text:
            return Response(
                {"error": "session_id and text required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        if session_id not in sessions:
            return Response(
                {"error": "Session not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        session = sessions[session_id]

        if session["is_processing"]:
            return Response(
                {"error": "Already processing"},
                status=status.HTTP_409_CONFLICT
            )

        session["is_processing"] = True

        try:
            interviewer = session["interviewer"]

            ai_response = interviewer.send_message(text)
            interview_ended = interviewer.is_ended()

            # -------- TTS --------
            audio = None
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    tts_response = await client.post(
                        TTS_API_URL,
                        json={"text": ai_response}
                    )
                    audio = tts_response.json().get("audio")
            except Exception:
                pass

            return Response({
                "success": True,
                "text": ai_response,
                "audio": audio,
                "interview_ended": interview_ended
            })

        finally:
            session["is_processing"] = False



# ================== TRANSCRIBE (ASR) ==================

class TranscribeAudioView(APIView):
    authentication_classes = []
    permission_classes = []
    parser_classes = [MultiPartParser, FormParser]

    async def post(self, request):
        audio_file = request.FILES.get("audio_file")

        if not audio_file:
            return Response(
                {"error": "audio_file required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                files = {
                    "audio_file": (
                        audio_file.name,
                        audio_file.read(),
                        audio_file.content_type
                    )
                }
                asr_response = await client.post(
                    ASR_API_URL,
                    files=files
                )
                result = asr_response.json()

            return Response({
                "success": True,
                "text": result.get("response", "")
            })

        except Exception as e:
            return Response(
                {"error": f"ASR failed: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )



# ================== END INTERVIEW ==================

class EndInterviewView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        session_id = request.data.get("session_id")

        if session_id not in sessions:
            return Response(
                {"error": "Session not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        interviewer = sessions[session_id]["interviewer"]
        history = interviewer.get_conversation_history()

        del sessions[session_id]

        return Response({
            "success": True,
            "conversation_history": history
        })


# ================== SESSION STATUS ==================

class SessionStatusView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request, session_id):
        if session_id not in sessions:
            return Response({"exists": False})

        session = sessions[session_id]
        interviewer = session["interviewer"]

        return Response({
            "exists": True,
            "is_processing": session["is_processing"],
            "interview_ended": interviewer.is_ended(),
            "conversation_turns": interviewer.conversation_turns
        })


