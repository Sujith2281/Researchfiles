import asyncio
import httpx
from django.shortcuts import render
from django.http import JsonResponse
from django.views import View
from .AI_engine import AIInterviewer
import json

# ================== CONFIG ==================
TTS_API_URL = "http://localhost:5000/echo"
ASR_API_URL = "https://speech.pranathiss.com/api/vad-speech-to-text/"
PROFILER_DATA_API_URL = "http://localhost:8000/profiler/parsed-data/"

# ================== IN-MEMORY SESSION STORE ==================
sessions: dict[str, dict] = {}

temp_data = {
    "parsed_resume": {
        "name": "Sanjay dutt",
        "skills": [
            "Python",
            "Django",
            "Hugging Face",
            "Natural Language Processing (NLP)",
            "Deep Learning",
            "PyTorch",
            "LangChain",
            "Generative AI",
        ]
    },
    "parsed_jd": {
        "required_skills": [
            "Generative AI application development",
            "AWS Bedrock",
            "Python programming",
            "Building APIs and workflows",
            "Infrastructure as Code (CloudFormation, CDK, Terraform)",
            "Observability (CloudWatch, X-Ray)",
            "Security and governance best practices"
        ],
        "experience": "Strong hands-on experience in AWS-native Generative AI solutions with a focus on production-grade applications.",
        "tools": [
            "CDK",
            "Terraform",
            "CloudWatch",
            "X-Ray"
        ]
    },
    "intention": "1. Key areas to focus on during the interview:\n   - Generative AI application development using AWS services.\n   - Python programming proficiency and API building.\n   - Experience with cloud-native solutions and CI/CD practices.\n   - Understanding of observability and security in cloud environments.\n\n2. Specific technical questions to ask:\n   - Can you describe a project where you utilized AWS Bedrock for a Generative AI application?\n   "
}
# ================== ROOT ==================
class RootRedirectView(View):
    async def get(self, request):
        return render(request, "interviewer/interview_page.html")


# ================== START INTERVIEW ==================
class StartInterviewView(View):
    async def post(self, request):
        #data = await request.json()
        data = json.loads(request.body.decode('utf-8'))
        session_id = data.get("session_id")
        print("on session ")
        if not session_id:
            return JsonResponse({"error": "session_id required"}, status=400)

        # -------- FETCH PROFILER DATA --------
        # try:
        #     async with httpx.AsyncClient(timeout=30.0) as client:
        #         print("Fetching profiler data...")
        #         profiler_resp = await client.get(PROFILER_DATA_API_URL)
        #     profiler_resp.raise_for_status()
        #     profiler_data = profiler_resp.json()
        #     if not profiler_data:
        #         profiler_data = temp_data
        #         print("temp_data used")
        #     parsed_resume = profiler_data.get("parsed_resume")
        #     parsed_jd = profiler_data.get("parsed_jd")
        #     intention = profiler_data.get("intention")

        #     if not parsed_resume or not parsed_jd:
        #         return JsonResponse({"error": "Invalid profiler data"}, status=400)
        # except Exception as e:

        #     return JsonResponse({"error": f"Profiler API error: {str(e)}"}, status=502)

        # -------- FETCH PROFILER DATA --------
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                print("Fetching profiler data...")
                profiler_resp = await client.get(PROFILER_DATA_API_URL)
            profiler_resp.raise_for_status()
            profiler_data = profiler_resp.json()
            print(f"Profiler data received: {profiler_data}")
            
            parsed_resume = profiler_data.get("parsed_resume")
            parsed_jd = profiler_data.get("parsed_jd")
            intention = profiler_data.get("intention")
            
            # Use temp_data if any required data is missing
            if not parsed_resume or not parsed_jd:
                print("Using temp_data - profiler data incomplete")
                profiler_data = temp_data
                parsed_resume = profiler_data.get("parsed_resume")
                parsed_jd = profiler_data.get("parsed_jd")
                intention = profiler_data.get("intention")

        except Exception as e:
            print(f"Profiler API failed, using temp_data: {e}")
            profiler_data = temp_data
            parsed_resume = profiler_data.get("parsed_resume")
            parsed_jd = profiler_data.get("parsed_jd")
            intention = profiler_data.get("intention")



        # -------- CREATE INTERVIEWER --------
        try:
            interviewer = AIInterviewer(resume=parsed_resume, job_description=parsed_jd, intention=intention)
        except TypeError:
            interviewer = AIInterviewer(parsed_resume, parsed_jd)

        # Run blocking AI call in thread
        greeting = await asyncio.to_thread(interviewer.start_interview)

        # -------- STORE SESSION --------
        sessions[session_id] = {"interviewer": interviewer, "is_processing": False}

        # -------- TTS --------
        audio = None
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                tts_resp = await client.post(TTS_API_URL, json={"text": greeting})
                audio = tts_resp.json().get("audio")
        except Exception:
            pass

        return JsonResponse({
            "success": True,
            "text": greeting,
            "audio": audio,
            "interview_ended": False
        })


# ================== SEND MESSAGE ==================
class SendMessageView(View):
    async def post(self, request):
        #data = await request.json()
        data = json.loads(request.body.decode('utf-8'))
        session_id = data.get("session_id")
        text = data.get("text")

        if not session_id or not text:
            return JsonResponse({"error": "session_id and text required"}, status=400)

        if session_id not in sessions:
            return JsonResponse({"error": "Session not found"}, status=404)

        session = sessions[session_id]
        if session["is_processing"]:
            return JsonResponse({"error": "Already processing"}, status=409)

        session["is_processing"] = True
        try:
            interviewer = session["interviewer"]
            ai_response = await asyncio.to_thread(interviewer.send_message, text)
            interview_ended = interviewer.is_ended()

            audio = None
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    tts_resp = await client.post(TTS_API_URL, json={"text": ai_response})
                    audio = tts_resp.json().get("audio")
            except Exception:
                pass

            return JsonResponse({
                "success": True,
                "text": ai_response,
                "audio": audio,
                "interview_ended": interview_ended
            })
        finally:
            session["is_processing"] = False


# ================== TRANSCRIBE AUDIO ==================
class TranscribeAudioView(View):
    async def post(self, request):
        audio_file = request.FILES.get("audio_file")
        if not audio_file:
            return JsonResponse({"error": "audio_file required"}, status=400)

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                files = {"audio_file": (audio_file.name, audio_file.read(), audio_file.content_type)}
                asr_resp = await client.post(ASR_API_URL, files=files)
                result = asr_resp.json()

            return JsonResponse({"success": True, "text": result.get("response", "")})
        except Exception as e:
            return JsonResponse({"error": f"ASR failed: {str(e)}"}, status=500)


# ================== END INTERVIEW ==================
class EndInterviewView(View):
    async def post(self, request):
        #data = await request.json()
        data = json.loads(request.body.decode('utf-8'))
        session_id = data.get("session_id")

        if session_id not in sessions:
            return JsonResponse({"error": "Session not found"}, status=404)

        interviewer = sessions[session_id]["interviewer"]
        history = interviewer.get_conversation_history()
        del sessions[session_id]

        return JsonResponse({"success": True, "conversation_history": history})


# ================== SESSION STATUS ==================
class SessionStatusView(View):
    async def get(self, request, session_id):
        if session_id not in sessions:
            return JsonResponse({"exists": False})

        session = sessions[session_id]
        interviewer = session["interviewer"]

        return JsonResponse({
            "exists": True,
            "is_processing": session["is_processing"],
            "interview_ended": interviewer.is_ended(),
            "conversation_turns": interviewer.conversation_turns
        })










