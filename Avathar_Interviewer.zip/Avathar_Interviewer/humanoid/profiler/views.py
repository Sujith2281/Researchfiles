import os
import json
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import PyPDF2
from openai import OpenAI
from dotenv import load_dotenv
from pydantic import BaseModel
from typing import List

# Load environment variables
load_dotenv()

# Pydantic models for structured output
class ResumeData(BaseModel):
    name: str
    skills: List[str]

class JDData(BaseModel):
    required_skills: List[str]
    experience: str
    tools: List[str]

# Initialize OpenAI client
try:
    client = OpenAI()
    print("DEBUG: OpenAI client initialized successfully")
except Exception as e:
    print(f"DEBUG: OpenAI client initialization failed: {e}")
    client = None

# Storage for parsed data (in production, use database)
parsed_data = {
    'parsed_resume': None,
    'parsed_jd': None,
    'intention': None
}


# -------------------------
# Template View
# -------------------------
class ProfilerPageView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        """Render the main profiler page"""
        return render(request, 'profiler/profiler.html')


# -------------------------
# Resume Parser
# -------------------------
class ResumeParserView(APIView):
    def post(self, request):
        try:
            if 'pdf_file' in request.FILES:
                pdf_file = request.FILES['pdf_file']
                text = extract_text_from_pdf(pdf_file)
            elif 'raw_text' in request.data:
                text = request.data['raw_text']
            else:
                return Response(
                    {'error': 'No PDF file or raw text provided'},
                    status=status.HTTP_400_BAD_REQUEST
                )

            resume_data = extract_resume_details(text)
            parsed_data['parsed_resume'] = resume_data

            return Response({
                'success': True,
                'data': resume_data,
                'message': 'Resume parsed successfully'
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


# -------------------------
# Job Description Parser
# -------------------------
class JDParserView(APIView):
    def post(self, request):
        try:
            if 'pdf_file' in request.FILES:
                pdf_file = request.FILES['pdf_file']
                text = extract_text_from_pdf(pdf_file)
            elif 'raw_text' in request.data:
                text = request.data['raw_text']
            else:
                return Response(
                    {'error': 'No PDF file or raw text provided'},
                    status=status.HTTP_400_BAD_REQUEST
                )

            jd_data = extract_jd_details(text)
            parsed_data['parsed_jd'] = jd_data

            return Response({
                'success': True,
                'data': jd_data,
                'message': 'Job description parsed successfully'
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


# -------------------------
# Interview Intention Builder
# -------------------------
class InterviewIntentionView(APIView):
    def post(self, request):
        try:
            if not parsed_data['parsed_resume'] or not parsed_data['parsed_jd']:
                return Response(
                    {'error': 'Both resume and job description must be parsed first'},
                    status=status.HTTP_400_BAD_REQUEST
                )

            intention = generate_interview_intention(
                parsed_data['parsed_resume'],
                parsed_data['parsed_jd']
            )

            parsed_data['intention'] = intention

            return Response({
                'success': True,
                'intention': intention,
                'message': 'Interview intention generated successfully'
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


# -------------------------
# Status API
# -------------------------
class StatusView(APIView):
    def get(self, request):
        return Response({
            'resume_parsed': parsed_data['parsed_resume'] is not None,
            'jd_parsed': parsed_data['parsed_jd'] is not None,
            'intention_ready': parsed_data['intention'] is not None
        })


# -------------------------
# Utility Functions
# -------------------------
def extract_text_from_pdf(pdf_file):
    text = ""
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    for page in pdf_reader.pages:
        text += page.extract_text()
    return text


def extract_resume_details(text):
    try:
        response = client.beta.chat.completions.parse(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": f"Extract name and technical skills from this resume: {text}"}
            ],
            response_format=ResumeData,
        )
        
        resume_data = response.choices[0].message.parsed
        return resume_data.model_dump()
        
    except Exception as e:
        print(f"DEBUG: OpenAI API error: {e}")
        return {"name": "Unknown", "skills": []}


def extract_jd_details(text):
    try:
        response = client.beta.chat.completions.parse(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": f"Extract required skills, experience, and tools from this job description: {text}"}
            ],
            response_format=JDData,
        )
        
        jd_data = response.choices[0].message.parsed
        return jd_data.model_dump()
        
    except Exception as e:
        print(f"DEBUG: OpenAI API error: {e}")
        return {"required_skills": [], "experience": "Not specified", "tools": []}


def generate_interview_intention(resume_data, jd_data):
    prompt = f"""
    Based on the candidate's resume and job description, create interview objectives.

    Candidate Profile:
    Name: {resume_data.get('name', 'Unknown')}
    Skills: {', '.join(resume_data.get('skills', []))}

    Job Requirements:
    Required Skills: {', '.join(jd_data.get('required_skills', []))}
    Experience: {jd_data.get('experience', 'Not specified')}
    Tools: {', '.join(jd_data.get('tools', []))}

    - Analyze the match between candidate's skills and job requirements

    Generate a comprehensive interview intention that includes:
    1. Key areas to focus on during the interview
    2. Specific technical questions to ask
    3. Skills gap analysis
    4. Interview objectives

    Return as string response directly do not include pre and post positional phrase, and response within 220 words.
    """
    
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.4
    )

    return response.choices[0].message.content


# ParsedDataView
class ParsedDataView(APIView):
    def get(self, request):
        return Response(parsed_data)