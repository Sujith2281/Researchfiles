# from django.urls import path
# from . import views

# urlpatterns = [
#     path('', views.profiler_page, name='profiler_page'),
#     path('api/parse-resume/', views.resume_parser, name='parse_resume'),
#     path('api/parse-jd/', views.jd_parsing, name='parse_jd'),
#     path('api/build-intention/', views.build_interview_intention, name='build_intention'),
#     path('api/status/', views.get_status, name='get_status'),
# ]



from django.urls import path
from .views import (
    ProfilerPageView,
    ResumeParserView,
    JDParserView,
    InterviewIntentionView,
    StatusView,
    ParsedDataView
)

urlpatterns = [
    path('', ProfilerPageView.as_view(), name='profiler_page'),
    path('resume-parser/', ResumeParserView.as_view(), name='resume_parser'),
    path('jd-parser/', JDParserView.as_view(), name='jd_parser'),
    path('build-intention/', InterviewIntentionView.as_view(), name='build_intention'),
    path('status/', StatusView.as_view(), name='status'),
    # urls.py
    path("parsed-data/", ParsedDataView.as_view()),
]
