import os
import json
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import PyPDF2
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize OpenAI client
client = OpenAI()

# Storage for parsed data (in production, use database)
parsed_data = {
    'parsed_resume': None,
    'parsed_jd': None,
    'intention': None
}

def profiler_page(request):
    """Render the main profiler page"""
    return render(request, 'profiler/profiler.html')

@api_view(['POST'])
def resume_parser(request):
    """Parse resume from PDF or raw text"""
    try:
        if 'pdf_file' in request.FILES:
            # Handle PDF upload
            pdf_file = request.FILES['pdf_file']
            text = extract_text_from_pdf(pdf_file)
        elif 'raw_text' in request.data:
            # Handle raw text input
            text = request.data['raw_text']
        else:
            return Response({'error': 'No PDF file or raw text provided'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Extract resume details using OpenAI
        resume_data = extract_resume_details(text)
        parsed_data['parsed_resume'] = resume_data
        
        return Response({
            'success': True,
            'data': resume_data,
            'message': 'Resume parsed successfully'
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def jd_parsing(request):
    """Parse job description from PDF or raw text"""
    try:
        if 'pdf_file' in request.FILES:
            # Handle PDF upload
            pdf_file = request.FILES['pdf_file']
            text = extract_text_from_pdf(pdf_file)
        elif 'raw_text' in request.data:
            # Handle raw text input
            text = request.data['raw_text']
        else:
            return Response({'error': 'No PDF file or raw text provided'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Extract JD details using OpenAI
        jd_data = extract_jd_details(text)
        parsed_data['parsed_jd'] = jd_data
        
        return Response({
            'success': True,
            'data': jd_data,
            'message': 'Job description parsed successfully'
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def build_interview_intention(request):
    """Generate interview intention based on parsed resume and JD"""
    try:
        if not parsed_data['parsed_resume'] or not parsed_data['parsed_jd']:
            return Response({'error': 'Both resume and job description must be parsed first'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Generate interview intention using OpenAI
        intention = generate_interview_intention(parsed_data['parsed_resume'], parsed_data['parsed_jd'])
        parsed_data['intention'] = intention
        
        return Response({
            'success': True,
            'intention': intention,
            'message': 'Interview intention generated successfully'
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
def get_status(request):
    """Get current parsing status"""
    return Response({
        'resume_parsed': parsed_data['parsed_resume'] is not None,
        'jd_parsed': parsed_data['parsed_jd'] is not None,
        'intention_ready': parsed_data['intention'] is not None
    })

def extract_text_from_pdf(pdf_file):
    """Extract text from PDF using PyPDF2"""
    text = ""
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    for page in pdf_reader.pages:
        text += page.extract_text()
    return text

def extract_resume_details(text):
    """Extract name and skills from resume text using OpenAI"""
    prompt = f"""
    Extract the following information from this resume text and return as JSON:
    - name: Full name of the candidate
    - skills: List of technical skills mentioned
    
    Resume text:
    {text}
    
    Return only valid JSON format.
    """
    
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    
    try:
        return json.loads(response.choices[0].message.content)
    except:
        return {"name": "Unknown", "skills": []}

def extract_jd_details(text):
    """Extract required skills, experience and tools from JD using OpenAI"""
    prompt = f"""
    Extract the following information from this job description and return as JSON:
    - required_skills: List of required technical skills
    - experience: Required years of experience
    - tools: List of tools/technologies mentioned
    
    Job Description text:
    {text}
    
    Return only valid JSON format.
    """
    
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    
    try:
        return json.loads(response.choices[0].message.content)
    except:
        return {"required_skills": [], "experience": "Not specified", "tools": []}

def generate_interview_intention(resume_data, jd_data):
    """Generate interview objectives using OpenAI"""
    prompt = f"""
    Based on the candidate's resume and job description, create interview objectives.
    
    Candidate Profile:
    Name: {resume_data.get('name', 'Unknown')}
    Skills: {', '.join(resume_data.get('skills', []))}
    
    Job Requirements:
    Required Skills: {', '.join(jd_data.get('required_skills', []))}
    Experience: {jd_data.get('experience', 'Not specified')}
    Tools: {', '.join(jd_data.get('tools', []))}
    
    Generate a comprehensive interview intention that includes:
    1. Key areas to focus on during the interview
    2. Specific technical questions to ask
    3. Skills gap analysis
    4. Interview objectives
    
    Return as a detailed string.
    """
    
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    
    return response.choices[0].message.content
