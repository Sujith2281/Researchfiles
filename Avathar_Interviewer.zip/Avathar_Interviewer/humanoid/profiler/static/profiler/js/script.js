class ProfilerApp {
    constructor() {
        this.resumeParsed = false;
        this.jdParsed = false;
        this.intentionReady = false;
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // File upload listeners
        document.getElementById('resumeFile').addEventListener('change', (e) => {
            this.handleFileUpload(e, 'resume');
        });

        document.getElementById('jdFile').addEventListener('change', (e) => {
            this.handleFileUpload(e, 'jd');
        });

        // Text input listeners
        document.getElementById('resumeText').addEventListener('input', () => {
            this.checkProcessButtonState();
        });

        document.getElementById('jdText').addEventListener('input', () => {
            this.checkProcessButtonState();
        });

        // Process button
        document.getElementById('processBtn').addEventListener('click', () => {
            this.processDocuments();
        });

        // Proceed button
        document.getElementById('proceedBtn').addEventListener('click', () => {
            this.proceedToInterview();
        });
    }

    async handleFileUpload(event, type) {
        const file = event.target.files[0];
        if (!file) return;

        const statusElement = document.getElementById(`${type}Status`);
        statusElement.textContent = `${file.name} selected`;
        statusElement.className = 'status success';

        this.checkProcessButtonState();
    }

    checkProcessButtonState() {
        const resumeFile = document.getElementById('resumeFile').files[0];
        const resumeText = document.getElementById('resumeText').value.trim();
        const jdFile = document.getElementById('jdFile').files[0];
        const jdText = document.getElementById('jdText').value.trim();

        const hasResume = resumeFile || resumeText;
        const hasJD = jdFile || jdText;

        document.getElementById('processBtn').disabled = !(hasResume && hasJD);
    }

    async processDocuments() {
        this.showProcessing(true);
        
        try {
            // Process resume
            await this.parseResume();
            
            // Process JD
            await this.parseJD();
            
            // Generate intention
            await this.buildIntention();
            
            this.showProcessing(false);
            this.showProceedButton();
            
        } catch (error) {
            this.showProcessing(false);
            this.showError('Processing failed: ' + error.message);
        }
    }

    async parseResume() {
        const resumeFile = document.getElementById('resumeFile').files[0];
        const resumeText = document.getElementById('resumeText').value.trim();

        let response;
        
        if (resumeFile) {
            const formData = new FormData();
            formData.append('pdf_file', resumeFile);
            response = await fetch('/profiler/resume-parser/', {
                method: 'POST',
                body: formData
            });
        } else {
            response = await fetch('/profiler/resume-parser/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ raw_text: resumeText })
            });
        }

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Resume parsing failed');
        }

        this.resumeParsed = true;
        this.updateStatus('resumeStatus', 'Resume parsed successfully', 'success');
        this.displayResults('resumeResults', data.data);
    }

    async parseJD() {
        const jdFile = document.getElementById('jdFile').files[0];
        const jdText = document.getElementById('jdText').value.trim();

        let response;
        
        if (jdFile) {
            const formData = new FormData();
            formData.append('pdf_file', jdFile);
            response = await fetch('/profiler/jd-parser/', {
                method: 'POST',
                body: formData
            });
        } else {
            response = await fetch('/profiler/jd-parser/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ raw_text: jdText })
            });
        }

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'JD parsing failed');
        }

        this.jdParsed = true;
        this.updateStatus('jdStatus', 'Job description parsed successfully', 'success');
        this.displayResults('jdResults', data.data);
    }

    async buildIntention() {
        const response = await fetch('/profiler/build-intention/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Intention generation failed');
        }

        this.intentionReady = true;
        this.displayResults('intentionResults', data.intention);
    }

    showProcessing(show) {
        const processingIndicator = document.getElementById('processingIndicator');
        const processBtn = document.getElementById('processBtn');
        
        if (show) {
            processingIndicator.style.display = 'flex';
            processBtn.style.display = 'none';
        } else {
            processingIndicator.style.display = 'none';
            processBtn.style.display = 'inline-block';
        }
    }

    showProceedButton() {
        document.getElementById('proceedBtn').style.display = 'inline-block';
        document.getElementById('processBtn').style.display = 'none';
        document.getElementById('resultsSection').style.display = 'block';
    }

    updateStatus(elementId, message, type) {
        const element = document.getElementById(elementId);
        element.textContent = message;
        element.className = `status ${type}`;
    }

    displayResults(elementId, data) {
        const element = document.getElementById(elementId);
        
        if (typeof data === 'object') {
            element.innerHTML = this.formatObjectData(data);
        } else {
            element.innerHTML = `<pre>${data}</pre>`;
        }
    }

    formatObjectData(data) {
        let html = '';
        for (const [key, value] of Object.entries(data)) {
            html += `<div><strong>${key}:</strong> `;
            if (Array.isArray(value)) {
                html += value.join(', ');
            } else {
                html += value;
            }
            html += '</div>';
        }
        return html;
    }

    showError(message) {
        alert(message); // In production, use a better error display
    }

    proceedToInterview() {
        // Redirect to interview app
        window.location.href = '/interviewer/';
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ProfilerApp();
});