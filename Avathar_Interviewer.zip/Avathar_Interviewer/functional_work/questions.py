import re,os
from typing import List, Dict, Any
from zoneinfo import ZoneInfo
from openai import OpenAI
from pydantic import BaseModel
import re
from datetime import datetime
import json
#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'

# Initialize OpenAI client with API key from environment
from dotenv import load_dotenv
load_dotenv() 
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')

if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY not loaded")

client = OpenAI(api_key=OPENAI_API_KEY)


# -------------------------
# Pydantic Models for Structured Output
# -------------------------
class InterviewQuestion(BaseModel):
    """Individual interview question"""
    question_number: int
    question_text: str


class InterviewQuestionsResponse(BaseModel):
    """Structured response containing all interview questions"""
    questions: List[InterviewQuestion]






def generate_questions(
    designation: str,
    level: str,
    skill_keywords: List[str],
    n_questions: int

    ) -> Dict[str, Any]:
    """
    Generate technical interview questions for a given designation and experience level.

    The LLM is allowed to respond in natural language.
    This function is responsible for parsing and structuring the output
    into a clean JSON-compatible dictionary.

    Args:
        designation (str): Job designation (e.g., "Backend Engineer", "Data Scientist")
        level (str): Experience level (e.g., "entry", "mid", "senior")
        skill_keywords (List[str]): List of relevant skills/technologies
        n_questions (int): Total number of questions to generate

    Returns:
        Dict[str, Any]: JSON-style response with questions and metadata
    """

    try:
        # -------------------------
        # Input validation
        # -------------------------
        if not designation or not level:
            return {
                "success": False,
                "error": "Both 'designation' and 'level' are required."
            }

        if not isinstance(skill_keywords, list):
            return {
                "success": False,
                "error": "'skill_keywords' must be a list of strings."
            }

        if not isinstance(n_questions, int) or n_questions <= 0:
            return {
                "success": False,
                "error": "'n_questions' must be a positive integer."
            }

        # -------------------------
        # Prompt construction
        # -------------------------
        prompt = f"""
Consider yourself as a interveiwer
Generate exactly {n_questions} technical interview questions for a {level}-level {designation}.
Use the following skills as guidance where relevant: {skill_keywords}.

MANDATORY PERSONALIZED QUESTIONS (Must be first 3):
1. Based on the candidate's professional background and career progression.
2. Based on a specific project the candidate has worked on.
3. Based on technical challenges, trade-offs, or decisions made in that project.

QUESTIONS 4–{n_questions}:
- Cover different technical competencies (no repetition of the same skill).
- Mix conceptual, practical, scenario-based, and decision-making questions.
- Match the difficulty to the {level} level.
- Use real-world, concrete scenarios.
- Avoid cliché or generic interview questions.

FORMAT RULES:
- Number each question (1, 2, 3, ...)
- Do NOT include labels, headings, or explanations.
- Do NOT use placeholders like [technology] or [example].
- Each question must be ready to ask as-is.
"""

        # -------------------------
        # OpenAI call with Structured Output (Pydantic)
        # -------------------------
        response = client.beta.chat.completions.parse(
            model=OPENAI_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an experienced technical interviewer. "
                        "Generate clear, practical, and designation-appropriate interview questions. "
                        "Return the response as structured JSON with numbered questions."
                    )
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            response_format=InterviewQuestionsResponse,
            temperature=0.9
        )

        # -------------------------
        # Extract parsed questions from Pydantic response
        # -------------------------
        parsed_response = response.choices[0].message.parsed
        questions: List[str] = [q.question_text for q in parsed_response.questions]
        
        print("parsed model response: ")
        print(json.dumps([{"q": q.question_number, "text": q.question_text} for q in parsed_response.questions], indent=2))
        print("="*80)

        # Trim in case LLM generated extra
        questions = questions[:n_questions]

        # -------------------------
        # Structure JSON response
        # -------------------------
        questions_dict = {
            f"q{i+1}": q for i, q in enumerate(questions)
        }

        return {
            "success": True,
            "designation": designation,
            "level": level,
            "skills_used_as_context": skill_keywords,
            "questions": questions_dict,
            "total_questions": len(questions_dict)
        }

    except Exception as exc:
        return {
            "success": False,
            "error": f"Unhandled error: {str(exc)}"
        }


designation = "Data Scientist"
level = "Intermediate"
skill_keywords = [
    "python",
    "gen-ai",
    "vlm",
    "llm",
    "langchain",
    "django"
]
n_questions = 10

result = generate_questions(
    designation=designation,
    level=level,
    skill_keywords=skill_keywords,
    n_questions=n_questions
)

# print(result)
# print("="*10)
print(json.dumps(result, indent=2))