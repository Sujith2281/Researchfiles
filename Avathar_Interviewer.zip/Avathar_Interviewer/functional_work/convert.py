from pathlib import Path
import requests
import tempfile
import os
from typing import Dict, Optional

# Endpoint URL for speech-to-text conversion
SPEECH_TO_TEXT_ENDPOINT = "https://speech.pranathiss.com/api/vad-speech-to-text/"

# Video file extensions
VIDEO_EXTENSIONS = {'.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv', '.webm', '.m4v', '.3gp', '.ogv'}
# Audio file extensions
AUDIO_EXTENSIONS = {'.mp3', '.wav', '.aac', '.flac', '.m4a', '.ogg', '.wma', '.aiff'}


def extract_audio_from_video(video_path: str) -> Optional[str]:
    """
    Extract audio from video file and save as MP3.
    
    Args:
        video_path (str): Path to the video file
        
    Returns:
        Optional[str]: Path to the extracted audio file or None if extraction fails
    """
    try:
        from moviepy import VideoFileClip
        
        video_path = Path(video_path)
        
        # Create temporary audio file
        temp_audio = tempfile.NamedTemporaryFile(suffix='.mp3', delete=False)
        temp_audio.close()
        
        #print(f"Extracting audio from video: {video_path.name}...")
        
        with VideoFileClip(str(video_path)) as video:
            if video.audio is None:
                print("No audio track found in video")
                os.unlink(temp_audio.name)
                return None
            
            video.audio.write_audiofile(temp_audio.name, verbose=False, logger=None)
        
        print(f"Audio extracted successfully: {temp_audio.name}")
        return temp_audio.name
        
    except ImportError:
        print("Error: moviepy not installed. Install it with: pip install moviepy")
        return None
    except Exception as e:
        print(f"Error extracting audio from video: {e}")
        return None


def process_audio_or_video_to_text(file_path: str) -> Optional[str]:
    """
    Convert audio or video file to text using external speech-to-text API.
    Automatically extracts audio from video files for optimal performance.
    
    Args:
        file_path (str): Path to the audio or video file
        
    Returns:
        Optional[str]: Transcribed text or None if conversion fails
    """
    try:
        file_path = Path(file_path)

        if not file_path.exists():
            print(f"File not found: {file_path}")
            return None

        # Check if file is video and extract audio
        audio_to_send = file_path
        temp_audio_file = None
        
        if file_path.suffix.lower() in VIDEO_EXTENSIONS:
            print(f"Video detected: {file_path.name}. Extracting audio...")
            extracted_audio = extract_audio_from_video(str(file_path))
            
            if extracted_audio is None:
                print("Failed to extract audio from video")
                return None
            
            audio_to_send = Path(extracted_audio)
            temp_audio_file = extracted_audio
        
        try:
            with open(audio_to_send, 'rb') as audio_file:
                files = {
                    'audio_file': (audio_to_send.name, audio_file, 'application/octet-stream')
                }

                print(f"Sending to API: {audio_to_send.name}")
                response = requests.post(SPEECH_TO_TEXT_ENDPOINT, files=files)
                response.raise_for_status()

                result = response.json()
                return result.get('response', '').strip()
        
        finally:
            # Clean up temporary audio file if created
            if temp_audio_file and os.path.exists(temp_audio_file):
                os.unlink(temp_audio_file)
                print(f"Cleaned up temporary file: {temp_audio_file}")

    except Exception as e:
        print(f"Error processing Audio/Video file: {e}")
        return None


def process_question_response(question_data: Dict) -> Dict:
    """
    Process a question response in different formats (text, audio, video).
    
    Args:
        question_data (dict): Contains 'question', 'mode', and response data
        
    Returns:
        dict: Processed question and answer
    """
    question = question_data.get('question', '')
    mode = question_data.get('mode', 'text')

    answer = ""

    if mode == 'text':
        # Direct text response
        answer = question_data.get('response', '')

    elif mode == 'audio':
        # Convert audio to text
        audio_path = question_data.get('response_path', '')
        answer = process_audio_or_video_to_text(audio_path)
        if answer is None:
            answer = "[Audio transcription failed]"

    elif mode == 'video':
        # Convert video to text
        video_path = question_data.get('response_path', '')
        answer = process_audio_or_video_to_text(video_path)
        if answer is None:
            answer = "[Video transcription failed]"

    return {
        "question": question,
        "answer": answer
    }


def main():
    """
    Main function to test audio/video to text conversion.
    Update the file_path variable with your audio or video file path.
    """
    # UPDATE THIS PATH WITH YOUR AUDIO OR VIDEO FILE
    file_path =  r"C:\Users\sujith\Documents\Sound Recordings\Recording (2).m4a"  # e.g., "audio.mp3" or "video.mp4"
    
    print("=" * 60)
    print("Audio/Video to Text Converter - Test")
    print("=" * 60)
    
    # Test 1: Direct audio/video conversion
    print(f"\nProcessing file: {file_path}")
    result = process_audio_or_video_to_text(file_path)
    
    if result:
        print("\n✓ Transcription successful!")
        print(f"\nTranscribed Text:\n{result}")
    else:
        print("\n✗ Transcription failed!")
    
    # Test 2: Using question response format
    print("\n" + "=" * 60)
    print("Testing with question response format")
    print("=" * 60)
    
    question_data = {
        'question': 'What is your name?',
        'mode': 'audio',  # Change to 'video' if testing with video file
        'response_path': file_path
    }
    
    processed = process_question_response(question_data)
    print(f"\nQuestion: {processed['question']}")
    print(f"Answer: {processed['answer']}")
    print("=" * 60)


if __name__ == "__main__":
    main()