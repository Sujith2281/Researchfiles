
from openai import OpenAI
import re,os
from typing import List, Dict, Any




# Initialize OpenAI client with API key from environment
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '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')
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')

client = OpenAI(api_key=OPENAI_API_KEY)




"""
{
  "q1": {
    "question": "...",
    "answer": "..."
  },
  "q2": {
    "question": "...",
    "answer": "..."
  }
}



"""




def evaluate_answers(
    role: str,
    level: str,
    skill_keywords: List[str],
    qa_pairs: Dict[str, Dict[str, str]]
) -> Dict[str, Any]:
    """
    Evaluate candidate answers and return structured scores,
    performance metrics, and qualitative feedback.
    """

    try:
        # -------------------------
        # Validation
        # -------------------------
        if not role or not level:
            return {"success": False, "error": "role and level are required"}

        if not qa_pairs:
            return {"success": False, "error": "qa_pairs must not be empty"}

        # -------------------------
        # Build combined interview text
        # -------------------------
        interview_text = ""
        for key, qa in qa_pairs.items():
            interview_text += f"""
            Question {key}:
            Question: {qa.get("question")}
            Candidate Answer: {qa.get("answer")}
            """


###################prompt engineering
        # -------------------------
        # Prompt
        # -------------------------
        prompt = f"""
                You are an experienced technical interviewer evaluating a {role} candidate.

                Evaluate the candidate based on:
                - Technical correctness and depth
                - Problem-solving approach
                - Communication clarity
                - Professional and behavioral signals

                Relevant skills for context:
                {skill_keywords}

                FOR EACH QUESTION:
                - Briefly comment on quality
                - Give a numeric score between 1 and 100
                - End each evaluation with:
                Score: <number>/100

                AFTER ALL QUESTIONS, PROVIDE:

                1) Overall performance scores (1–100) using EXACT labels:
                Communication: <number>/100
                Problem Solving: <number>/100
                Technical Depth: <number>/100
                Behavioral: <number>/100
                Overall: <number>/100

                2) Strengths (1–3 items, comma-separated):
                Strengths: item1, item2, item3

                3) Areas for improvement (2–5 items, comma-separated):
                Improvements: item1, item2, item3, item4

                Do not use JSON. Do not use bullet lists.
                """

        # -------------------------
        # OpenAI call (single call)
        # -------------------------
        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": "You are a fair, structured, and unbiased interviewer."
                },
                {
                    "role": "user",
                    "content": prompt + interview_text
                }
            ],
            temperature=0.4
        )

        raw_text = response.choices[0].message.content

        # -------------------------
        # Parse per-question scores
        # -------------------------
        question_scores: Dict[str, int] = {}
        score_matches = re.findall(r"Score:\s*(\d{1,3})/100", raw_text)

        for idx, key in enumerate(qa_pairs.keys()):
            if idx < len(score_matches):
                question_scores[key] = min(100, int(score_matches[idx]))

        # -------------------------
        # Parse performance matrix
        # -------------------------
        def extract_metric(label: str) -> int:
            match = re.search(rf"{label}:\s*(\d{{1,3}})/100", raw_text, re.IGNORECASE)
            return min(100, int(match.group(1))) if match else 0

        performance_matrix = {
            "communication": extract_metric("Communication"),
            "problem_solving": extract_metric("Problem Solving"),
            "technical_depth": extract_metric("Technical Depth"),
            "behavioral": extract_metric("Behavioral"),
            "overall": extract_metric("Overall")
        }

        # -------------------------
        # Parse strengths & improvements
        # -------------------------
        def extract_list(label: str, min_items: int, max_items: int) -> List[str]:
            match = re.search(rf"{label}:\s*(.+)", raw_text, re.IGNORECASE)
            if not match:
                return []

            items = [i.strip() for i in match.group(1).split(",") if i.strip()]
            return items[:max_items] if len(items) >= min_items else items

        strengths = extract_list("Strengths", 1, 3)
        improvements = extract_list("Improvements", 2, 5)

        # -------------------------
        # Final structured response
        # -------------------------
        return {
            "success": True,
            "scores": question_scores,
            "performance_matrix": performance_matrix,
            "feedback": {
                "strength": strengths,
                "improvement": improvements
            }
        }

    except Exception as exc:
        return {
            "success": False,
            "error": f"Evaluation failed: {str(exc)}"
        }



"""
{
  "success": true,
  "scores": {
    "q1": 82,
    "q2": 74
  },
  "performance_matrix": {
    "communication": 78,
    "problem_solving": 81,
    "technical_depth": 75,
    "behavioral": 70,
    "overall": 77
  },
  "feedback": {
    "strength": [
      "Clear explanation of technical concepts",
      "Strong problem decomposition",
      "Good understanding of LLM workflows"
    ],
    "improvement": [
      "Provide more concrete examples",
      "Discuss trade-offs more explicitly",
      "Improve clarity under complex scenarios"
    ]
  }
}



"""





import json

def main():
    role = "Data Scientist"
    level = "Intermediate"
    skill_keywords = [
        "python",
        "gen-ai",
        "vlm",
        "llm",
        "langchain",
        "django"
    ]

    # Hard-coded questions and candidate answers
    qa_pairs = {
        "q1": {
            "question": "Can you describe how your background in data science has influenced your approach to problem-solving in your recent projects?",
            "answer": (
                "My background in data science has trained me to approach problems systematically. "
                "I start by understanding the business objective, then explore data patterns, validate assumptions, "
                "and iterate using experiments. This approach helped me design scalable and measurable solutions."
            )
        },
        "q2": {
            "question": "Tell me about a specific project where you implemented a generative AI model. What were your key objectives, and what impact did the project have on the business?",
            "answer": (
                "I worked on a customer-support chatbot using an LLM. The objective was to reduce ticket resolution time. "
                "By fine-tuning prompts and integrating retrieval, we reduced human support load by around 30%."
            )
        },
        "q3": {
            "question": "During the generative AI project you mentioned, what were the most significant technical challenges you faced? How did you prioritize decisions when navigating those challenges?",
            "answer": (
                "The biggest challenge was hallucination and response consistency. "
                "I prioritized accuracy over creativity by adding grounding through vector search and strict prompt constraints."
            )
        },
        "q4": {
            "question": "Explain how you would approach building a language model using LangChain. What steps would you take to ensure the model is well-integrated with existing systems?",
            "answer": (
                "I would start by defining the use case, then build chains for prompt handling, retrieval, and memory. "
                "Integration would involve APIs, authentication, logging, and fallback strategies."
            )
        },
        "q5": {
            "question": "In a scenario where you need to clean and preprocess a large dataset using Python, what libraries and techniques would you employ?",
            "answer": (
                "I would use pandas, numpy, and sometimes Dask for scale. "
                "For missing values and outliers, I apply domain-aware imputation and validation rules."
            )
        },
        "q6": {
            "question": "Imagine you're tasked with creating a recommendation system using Django. What data sources would you consider, and how would you handle user privacy?",
            "answer": (
                "I would use user interaction data, historical preferences, and metadata. "
                "Privacy would be handled using anonymization, access controls, and secure storage."
            )
        },
        "q7": {
            "question": "Describe a situation where you had to explain a complex machine learning model to a non-technical audience.",
            "answer": (
                "I simplified the explanation using analogies and visuals, focusing on outcomes rather than math. "
                "This helped stakeholders understand the value without technical overload."
            )
        },
        "q8": {
            "question": "If you had to choose between using a pre-trained Large Language Model or training a custom model from scratch, what factors would influence your decision?",
            "answer": (
                "Factors include data availability, cost, latency, and customization needs. "
                "Most cases benefit from pre-trained models unless domain specificity is critical."
            )
        },
        "q9": {
            "question": "When working with Visual Language Models, how would you evaluate their performance?",
            "answer": (
                "I would use accuracy, precision-recall, and human evaluation. "
                "These metrics ensure both quantitative and qualitative performance."
            )
        },
        "q10": {
            "question": "In a multi-stage data pipeline, what strategies would you implement to optimize data processing speeds while ensuring data quality?",
            "answer": (
                "I would use parallel processing, caching, and data validation checks at each stage. "
                "Monitoring and logging help catch issues early."
            )
        }
    }

    # Call evaluation function
    result = evaluate_answers(
        role=role,
        level=level,
        skill_keywords=skill_keywords,
        qa_pairs=qa_pairs
    )

    # Pretty print output
    print("\n=== Candidate Evaluation Result ===\n")
    print(json.dumps(result, indent=2))
    print("\n=================================\n")


if __name__ == "__main__":
    main()







