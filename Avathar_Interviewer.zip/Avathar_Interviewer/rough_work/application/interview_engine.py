"""
AI Interview Engine - Simple OpenAI Chat with History
"""

from openai import OpenAI
from typing import List
from dotenv import load_dotenv
import os

load_dotenv()

# ============= CONFIG =============
MAX_CONVERSATION_TURNS = 50
MAX_TECHNICAL_QUESTIONS = 3

# ============= AI INTERVIEWER CLASS =============
class AIInterviewer:
    def __init__(self, resume: str, job_description: str):
        self.client = OpenAI()
        self.resume = resume
        self.job_description = job_description
        
        # Conversation history
        self.messages: List[dict] = []
        self.conversation_turns = 0
        self.interview_ended = False
        
        # System prompt instructing LLM to handle all logic
        self.system_prompt = f"""
You are a friendly, professional AI interviewer conducting a job interview.

CANDIDATE RESUME:
{resume}

JOB DESCRIPTION:
{job_description}

INTERVIEW FLOW:
1. GREETING: Greet the candidate warmly, extract their name from resume, and tell them you'll ask {MAX_TECHNICAL_QUESTIONS} technical questions. Ask if they're ready.
2. QUESTIONING: Ask relevant technical questions one at a time based on their experience. Be conversational and build on their answers.
3. INCOMPLETE RESPONSES: If the candidate's response seems incomplete (ends with "and", "or", "where", etc.), ask them to continue before moving to next question.
4. WRAPPING UP: After the candidate has answered {MAX_TECHNICAL_QUESTIONS} technical questions, do NOT ask more questions. Thank them warmly, mention a strength they showed, and suggest they can click "End Interview".

IMPORTANT RULES:
- Ask only one technical question at a time.
- Count technical questions implicitly using conversation context; do not continue beyond {MAX_TECHNICAL_QUESTIONS}.
- Sound natural, friendly, and interested — not robotic.
- Keep responses concise (2-3 sentences).
- Do not prefix responses with "AI:" or any role label.
"""

    def start_interview(self) -> str:
        """Start the interview with a greeting"""
        self.messages = []

        greeting_resp = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": "Start the interview"}
            ],
            temperature=0.7,
            max_tokens=100
        )

        greeting = greeting_resp.choices[0].message.content.strip()
        self.messages.append({"role": "user", "content": "Start the interview"})
        self.messages.append({"role": "assistant", "content": greeting})
        return greeting

    def send_message(self, user_input: str) -> str:
        """Send user message and get AI response"""
        if self.interview_ended:
            return "The interview has already ended."

        self.messages.append({"role": "user", "content": user_input})

        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "system", "content": self.system_prompt}] + self.messages,
            temperature=0.7,
            max_tokens=200
        )

        ai_response = response.choices[0].message.content.strip()
        self.messages.append({"role": "assistant", "content": ai_response})

        self.conversation_turns += 1
        if self.conversation_turns >= MAX_CONVERSATION_TURNS:
            self.interview_ended = True

        return ai_response

    def get_conversation_history(self) -> List[dict]:
        """Return the full conversation history"""
        return self.messages

    def is_ended(self) -> bool:
        """Check if the interview has ended"""
        return self.interview_ended


# ============= TEST =============
if __name__ == "__main__":
    RESUME = """Aman Kumar
Senior AI Engineer
5 years experience in data science, Gen AI, and Python"""

    JOB_DESCRIPTION = """Senior AI Engineer
Requirements: 4+ years Gen AI, Python, microservices"""

    interviewer = AIInterviewer(RESUME, JOB_DESCRIPTION)

    print("AI:", interviewer.start_interview(), "\n")

    turn = 0
    while not interviewer.is_ended() and turn < MAX_CONVERSATION_TURNS:
        user_input = input("You: ")
        if user_input.lower() in ["quit", "exit", "end"]:
            break
        ai_reply = interviewer.send_message(user_input)
        print(f"AI: {ai_reply}\n")
        turn += 1

    print("\n=== Interview Ended ===")
