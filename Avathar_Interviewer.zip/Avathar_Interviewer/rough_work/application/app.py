"""
FastAPI Interview Application with Human-like Timing
"""
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
import base64
from typing import Optional
from interview_engine import AIInterviewer

app = FastAPI()

# Enable CORS for ngrok
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Disable caching for static files during development
class NoCacheStaticFiles(StaticFiles):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    async def get_response(self, path, scope):
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

# Mount static files
app.mount("/static", NoCacheStaticFiles(directory="static"), name="static")

# In-memory session storage (use Redis/DB in production)
sessions = {}



    # Hardcoded resume and JD (can be replaced with DB/upload later)
RESUME = """Aman Kumar
Senior AI Engineer
5 years experience in data science, Gen AI, and Python"""
    
JOB_DESCRIPTION = """Senior AI Engineer
Requirements: 4+ years Gen AI, Python, microservices"""





# Config
TTS_API_URL = "http://localhost:5000/echo"
ASR_API_URL = "https://speech.pranathiss.com/api/vad-speech-to-text/"

# ============= MODELS =============
class StartInterviewRequest(BaseModel):
    session_id: str

class SendMessageRequest(BaseModel):
    session_id: str
    text: str

class EndInterviewRequest(BaseModel):
    session_id: str

# ============= ENDPOINTS =============

@app.get("/")
async def root():
    """Redirect to interview page"""
    return RedirectResponse(url="/static/index.html")

@app.post("/api/start-interview")
async def start_interview(req: StartInterviewRequest):
    """Initialize interview session and get first AI message"""
    

    
    # Create interviewer instance
    interviewer = AIInterviewer(RESUME, JOB_DESCRIPTION)
    greeting = interviewer.start_interview()
    
    # Store session
    sessions[req.session_id] = {
        "interviewer": interviewer,
        "is_processing": False
    }
    
    # Generate audio for greeting
    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            tts_response = await client.post(
                TTS_API_URL,
                json={"text": greeting}
            )
            audio_data = tts_response.json()
        except Exception as e:
            audio_data = {"audio": None, "success": False}
    
    return {
        "success": True,
        "text": greeting,
        "audio": audio_data.get("audio"),
        "interview_ended": False
    }


@app.post("/api/send-message")
async def send_message(req: SendMessageRequest):
    """Process user message and get AI response"""
    
    if req.session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    session = sessions[req.session_id]
    interviewer = session["interviewer"]
    
    # Check if already processing
    if session["is_processing"]:
        raise HTTPException(status_code=409, detail="Already processing")
    
    session["is_processing"] = True
    
    try:
        # Get AI response
        ai_response = interviewer.send_message(req.text)
        interview_ended = interviewer.is_ended()
        
        # Generate audio
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                tts_response = await client.post(
                    TTS_API_URL,
                    json={"text": ai_response}
                )
                audio_data = tts_response.json()
            except Exception as e:
                audio_data = {"audio": None, "success": False}
        
        return {
            "success": True,
            "text": ai_response,
            "audio": audio_data.get("audio"),
            "interview_ended": interview_ended
        }
    
    finally:
        session["is_processing"] = False


@app.post("/api/transcribe")
async def transcribe_audio(
    audio_file: UploadFile = File(...)
):
    """Transcribe user audio using ASR API"""
    
    # Call ASR API
    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            files = {"audio_file": (audio_file.filename, await audio_file.read(), audio_file.content_type)}
            asr_response = await client.post(ASR_API_URL, files=files)
            result = asr_response.json()
            
            return {
                "success": True,
                "text": result.get("response", "")
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"ASR failed: {str(e)}")


@app.post("/api/end-interview")
async def end_interview(req: EndInterviewRequest):
    """End interview and return conversation history"""
    
    if req.session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    session = sessions[req.session_id]
    interviewer = session["interviewer"]
    
    # Get conversation history
    history = interviewer.get_conversation_history()
    
    # Clean up session
    del sessions[req.session_id]
    
    return {
        "success": True,
        "conversation_history": history
    }


@app.get("/api/session-status/{session_id}")
async def get_session_status(session_id: str):
    """Check if session exists and get status"""
    
    if session_id not in sessions:
        return {"exists": False}
    
    session = sessions[session_id]
    interviewer = session["interviewer"]
    
    return {
        "exists": True,
        "is_processing": session["is_processing"],
        "interview_ended": interviewer.is_ended(),
        "conversation_turns": interviewer.conversation_turns
    }


if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*50)
    print("🚀 AI Interview Application Started!")
    print("="*50)
    print("📍 Open in browser: http://localhost:8000")
    print("📍 Or use: http://127.0.0.1:8000")
    print("="*50 + "\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
