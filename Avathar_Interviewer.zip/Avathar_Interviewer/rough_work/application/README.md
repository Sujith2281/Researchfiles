# AI Interview Web Application

Human-like interview experience with real-time voice interaction, VAD-based silence detection, and proper conversation timing.

## Features

- 🎥 Camera & microphone integration
- 🎤 Real-time speech recognition (ASR)
- 🔊 Text-to-speech (TTS) for AI responses
- ⏱️ Smart silence detection (5s initial, 1.8s after speaking)
- 🤖 Natural conversation flow
- 📝 Conversation history storage

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Create `.env` file with OpenAI API key:
```
OPENAI_API_KEY=your_key_here
```

3. Ensure TTS service is running on `http://localhost:5000/echo`

4. Run the application:
```bash
python app.py
```

5. Open browser: `http://localhost:8000/static/index.html`

## API Endpoints

### POST /api/start-interview
Start new interview session
```json
{
  "session_id": "session_123"
}
```

### POST /api/send-message
Send user message and get AI response
```json
{
  "session_id": "session_123",
  "text": "User response"
}
```

### POST /api/transcribe
Transcribe audio file
- Form data: `audio_file`, `session_id`

### POST /api/end-interview
End session and get conversation history
```json
{
  "session_id": "session_123"
}
```

### GET /api/session-status/{session_id}
Check session status

## Timing Logic

1. **Initial Silence**: 5 seconds before user starts speaking
2. **Active Silence**: 1.8 seconds after user starts speaking
3. **State Management**: System doesn't listen when AI is speaking or processing
4. **Auto-end**: Interview ends after reaching conversation limit or user clicks "End Interview"

## Architecture

```
Interview_app/
├─ app.py                 # FastAPI backend
├─ interview_engine.py    # AI interviewer logic
├─ requirements.txt       # Python dependencies
├─ static/
│   ├─ index.html         # Frontend UI
│   ├─ main.js            # VAD & timing logic
│   └─ style.css          # Styling
```

## Future Enhancements

- Resume/JD upload functionality
- Database integration for session persistence
- Redis for session management
- WebSocket for real-time updates
- Advanced VAD models
