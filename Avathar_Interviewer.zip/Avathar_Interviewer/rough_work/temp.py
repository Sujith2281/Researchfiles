"""
Simple AI Interviewer Module - LLM handles everything
"""

#GEMINI_API_KEY = "AIzaSyBZK0o0dkPAw6Jcb4V8R-yAaJ53JhxnjbI"



from langgraph.graph import StateGraph, END
#from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from typing import TypedDict, List
import os
#OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
from dotenv import load_dotenv
load_dotenv() 


MAX_QUESTIONS = 3
CONVERSATION_LIMIT = 10

# ============= STATE =============yes
class InterviewState(TypedDict):
    messages: List[dict]
    resume: str
    job_description: str
    questions_asked: int
    conversation_limit: int
    interview_ended: bool

# ============= NODES =============
def greeting_node(state: InterviewState) -> InterviewState:
    """LLM generates greeting"""
    llm = ChatOpenAI(
        model="gpt-4.1-nano-2025-04-14",
        #openai_api_key = OPENAI_API_KEY,
        temperature=0.1
    )
    
    prompt = f"""You are conducting a job interview.

                RESUME:
                {state['resume']}

                JOB DESCRIPTION:
                {state['job_description']}

                look at context of interview state and start the interview if it is not , if it is continue, if you start interview start with greeting and ask ready to begin and say ur an AI interviewer """

    response = llm.invoke(prompt)
    state["messages"].append({"role": "AI", "content": response.content})
    return state

def question_node(state: InterviewState) -> InterviewState:
    """LLM generates next question based on conversation"""
    llm = ChatOpenAI(
    model="gpt-4.1-nano-2025-04-14",
    #openai_api_key = OPENAI_API_KEY,
    temperature=0.4
    )
    
    conversation = "\n".join([f"{m['role']}: {m['content']}" for m in state["messages"]])
    
    prompt = f"""You are conducting a job interview using STAR method.

                You are an AI interviewer conducting a professional job interview.

                Guidelines:
                - Maintain a polite, professional, and conversational tone.
                - Begin with a warm greeting and ask if the candidate is ready.
                - Ask structured interview questions (STAR method) based on the resume and job description.
                - If the candidate gives irrelevant or off-topic answers, politely redirect: 
                e.g., "Let's stay focused on your professional experience, since this is an interview."
                - If the candidate misbehaves (rude, inappropriate), respond firmly but professionally:
                e.g., "Please remember this is a formal interview. Let's keep our discussion respectful."
                - If ASR input is unclear or garbled, ask for clarification:
                e.g., "I didn’t quite catch that. Could you repeat more clearly?"
                - If the candidate asks for feedback or goes off-script after the question quota, respond conversationally but avoid asking new interview questions.
                - End gracefully when either:
                - The conversation limit or time limit is reached, or
                - The candidate signals they are done.


                CONVERSATION:
                {conversation}

                You've asked some questions.as mentioned in conversation for context so in single conversational interview Max questions is {MAX_QUESTIONS} technical questions so after acheiving ur goal try to end the interview , remmember your state of interview is based on converstional context.
               """

    response = llm.invoke(prompt)
    state["messages"].append({"role": "AI", "content": response.content})
    state["conversation_limit"] -= 1
    
    if state["conversation_limit"] <= 0:
        state["interview_ended"] = True
    
    return state

# def should_continue(state: InterviewState) -> str:
#     """Router function"""
#     return "end" if state["interview_ended"] else "continue"


workflow = StateGraph(InterviewState)
workflow.add_node("greeting", greeting_node)
workflow.add_node("question", question_node)
workflow.set_entry_point("greeting")
workflow.add_edge("greeting", "question")
workflow.add_edge("question", END)



graph = workflow.compile()
# ============= AI INTERVIEWER =============
class AIInterviewer:
    def __init__(self, resume: str, job_description: str):
        #self.graph = create_graph()
        self.state = {
            "messages": [],
            "resume": resume,
            "job_description": job_description,
            "questions_asked": 3,
            "conversation_limit": 10,
            "interview_ended": False
        }
    
    def start_interview(self) -> str:
        """Start interview - LLM generates greeting"""
        #self.state = self.graph.invoke(self.state)
        result = graph.invoke(self.state, {"configurable": {"thread_id": "1"}})
        self.state = result
        return self.state["messages"][-1]["content"]
    
    
    def send_message(self, user_input: str) -> str:
        """User sends message, graph processes and LLM responds"""
        self.state["messages"].append({"role": "User", "content": user_input})
        
        # Call question_node directly, not the graph
        self.state = question_node(self.state)
        return self.state["messages"][-1]["content"]

# ============= USAGE =============
if __name__ == "__main__":
    RESUME = """John Doe
                Senior Software Engineer
                5 years experience in Python/Django"""

    JOB_DESCRIPTION = """Senior Backend Engineer
                        Requirements: 4+ years Python, microservices"""

    interviewer = AIInterviewer(RESUME, JOB_DESCRIPTION)
    
    print("AI:", interviewer.start_interview())
    print()
    
    while not interviewer.state["interview_ended"]:
        user_input = input("You: ")
        if user_input =='exit':
            break
        response = interviewer.send_message(user_input)
        print(f"AI: {response}\n")