"""
Simple AI Interviewer Module - LLM handles everything
"""

GEMINI_API_KEY = "AIzaSyBZK0o0dkPAw6Jcb4V8R-yAaJ53JhxnjbI"



from langgraph.graph import StateGraph, END
from langchain_google_genai import ChatGoogleGenerativeAI
from typing import TypedDict, List

# ============= CONFIG =============
#GEMINI_API_KEY = "YOUR_API_KEY"  # Replace this
MAX_QUESTIONS = 3

# ============= STATE =============yes
class InterviewState(TypedDict):
    messages: List[dict]
    resume: str
    job_description: str
    questions_asked: int
    interview_ended: bool

# ============= NODES =============
def greeting_node(state: InterviewState) -> InterviewState:
    """LLM generates greeting"""
    llm = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        google_api_key=GEMINI_API_KEY,
        temperature=0.7
    )
    
    prompt = f"""You are conducting a job interview.

                RESUME:
                {state['resume']}

                JOB DESCRIPTION:
                {state['job_description']}

                Start the interview with a warm greeting. Extract the candidate's name from the resume and greet them. Tell them you're an AI interviewer and ask if they're ready to begin."""

    response = llm.invoke(prompt)
    state["messages"].append({"role": "AI", "content": response.content})
    return state

def question_node(state: InterviewState) -> InterviewState:
    """LLM generates next question based on conversation"""
    llm = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash-lite",
        google_api_key=GEMINI_API_KEY,
        temperature=0.7
    )
    
    conversation = "\n".join([f"{m['role']}: {m['content']}" for m in state["messages"]])
    
    prompt = f"""You are conducting a job interview using STAR method.

                RESUME:
                {state['resume']}

                JOB DESCRIPTION:
                {state['job_description']}

                CONVERSATION:
                {conversation}

                You've asked {state['questions_asked']} questions. Max is {MAX_QUESTIONS}.
                {"Thank them and end the interview gracefully." if state['questions_asked'] >= MAX_QUESTIONS else "Ask the next relevant question based on their response. Keep it conversational."}"""

    response = llm.invoke(prompt)
    state["messages"].append({"role": "AI", "content": response.content})
    state["questions_asked"] += 1
    
    if state["questions_asked"] >= MAX_QUESTIONS:
        state["interview_ended"] = True
    
    return state

def should_continue(state: InterviewState) -> str:
    """Router function"""
    return "end" if state["interview_ended"] else "continue"


workflow = StateGraph(InterviewState)
workflow.add_node("greeting", greeting_node)
workflow.add_node("question", question_node)
workflow.set_entry_point("greeting")
workflow.add_edge("greeting", END)
workflow.add_edge("question", END)
graph = workflow.compile()
# ============= AI INTERVIEWER =============
class AIInterviewer:
    def __init__(self, resume: str, job_description: str):
        #self.graph = create_graph()
        self.state = {
            "messages": [],
            "resume": resume,
            "job_description": job_description,
            "questions_asked": 0,
            "interview_ended": False
        }
    
    def start_interview(self) -> str:
        """Start interview - LLM generates greeting"""
        #self.state = self.graph.invoke(self.state)
        result = graph.invoke(self.state, {"configurable": {"thread_id": "1"}})
        self.state = result
        return self.state["messages"][-1]["content"]
    
    
    def send_message(self, user_input: str) -> str:
        """User sends message, graph processes and LLM responds"""
        self.state["messages"].append({"role": "User", "content": user_input})
        
        # Call question_node directly, not the graph
        self.state = question_node(self.state)
        return self.state["messages"][-1]["content"]

# ============= USAGE =============
if __name__ == "__main__":
    RESUME = """John Doe
                Senior Software Engineer
                5 years experience in Python/Django"""

    JOB_DESCRIPTION = """Senior Backend Engineer
                        Requirements: 4+ years Python, microservices"""

    interviewer = AIInterviewer(RESUME, JOB_DESCRIPTION)
    
    print("AI:", interviewer.start_interview())
    print()
    
    while not interviewer.state["interview_ended"]:
        user_input = input("You: ")
        response = interviewer.send_message(user_input)
        print(f"AI: {response}\n")