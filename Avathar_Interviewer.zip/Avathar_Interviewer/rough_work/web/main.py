"""
FastAPI AI Interviewer with ASR and TTS
"""

from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import httpx
import base64
from typing import Optional
import uuid
from interview_engine import AIInterviewer

app = FastAPI(title="AI Interview Assistant")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Store active interview sessions
active_sessions = {}

# API Endpoints
TTS_ENDPOINT = "http://localhost:5000/echo"
ASR_ENDPOINT = "https://speech.pranathiss.com/api/vad-speech-to-text/"

# Hardcoded for now
RESUME = """Aman kumar
                Senior AI Engineer
                5 years experience in data science , Gen AI and Python
                skills : gen AI , data science , end to product design
"""

JOB_DESCRIPTION = """Senior AI Engineer
                Requirements: 

Company: InnovateTech Solutions

Requirements:
- 4+ years Gen AI ,Python, microservices
- Strong experience with microservices architecture
- Proficiency in Django or Flask frameworks
- Familiarity with cloud platforms (AWS/GCP/Azure)
- Strong problem-solving and communication skills

Responsibilities:
- Design and develop scalable GEN AI backend systems
- Build and maintain GEN AI integrations

"""

# Request/Response Models
class StartInterviewResponse(BaseModel):
    session_id: str
    ai_text: str
    ai_audio: str
    success: bool

class UserAudioRequest(BaseModel):
    session_id: str

class EndInterviewRequest(BaseModel):
    session_id: str

# ============= HELPER FUNCTIONS =============

async def text_to_speech(text: str) -> Optional[str]:
    """Convert text to speech using TTS API"""
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                TTS_ENDPOINT,
                json={"text": text},
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get("audio")
            else:
                print(f"TTS Error: {response.status_code}")
                return None
    except Exception as e:
        print(f"TTS Exception: {str(e)}")
        return None

async def speech_to_text(audio_file: UploadFile) -> Optional[str]:
    """Convert speech to text using ASR API"""
    try:
        content = await audio_file.read()  # Read once and store
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            files = {"audio_file": (audio_file.filename, content, audio_file.content_type)}
            response = await client.post(ASR_ENDPOINT, files=files)
            
            if response.status_code == 200:
                data = response.json()
                return data.get("response")
            else:
                print(f"ASR Error: {response.status_code}")
                return None
    except Exception as e:
        print(f"ASR Exception: {str(e)}")
        return None

# ============= API ENDPOINTS =============

@app.get("/")
async def root():
    """Health check endpoint"""
    return {"status": "AI Interview Assistant is running", "version": "1.0.0"}

@app.post("/start-interview", response_model=StartInterviewResponse)
async def start_interview():
    """
    Start a new interview session
    Returns session_id, initial greeting text, and audio
    """
    try:
        # Create new session
        session_id = str(uuid.uuid4())
        
        # Initialize interviewer
        interviewer = AIInterviewer(RESUME, JOB_DESCRIPTION)
        
        # Get initial greeting
        greeting_text = interviewer.start_interview()
        
        # Convert greeting to speech
        greeting_audio = await text_to_speech(greeting_text)
        
        if not greeting_audio:
            raise HTTPException(status_code=500, detail="Failed to generate audio")
        
        # Store session
        active_sessions[session_id] = interviewer
        
        return StartInterviewResponse(
            session_id=session_id,
            ai_text=greeting_text,
            ai_audio=greeting_audio,
            success=True
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error starting interview: {str(e)}")

@app.post("/send-audio")
async def send_audio(
    session_id: str= Form(...),
    audio_file: UploadFile = File(...)
):
    """
    Process user's audio response
    1. Convert audio to text (ASR)
    2. Send text to interview engine
    3. Get AI response
    4. Convert response to audio (TTS)
    """
    try:
        # Check if session exists
        if session_id not in active_sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        interviewer = active_sessions[session_id]
        
        # Check if interview has ended
        if interviewer.state.get("interview_ended", False):
            return JSONResponse(
                content={
                    "success": False,
                    "message": "Interview has already ended",
                    "interview_ended": True
                }
            )
        
        # Convert audio to text
        user_text = await speech_to_text(audio_file)
        
        if not user_text:
            raise HTTPException(status_code=500, detail="Failed to transcribe audio")
        
        # Get AI response
        ai_response_text = interviewer.send_message(user_text)
        
        # Convert AI response to audio
        ai_response_audio = await text_to_speech(ai_response_text)
        
        if not ai_response_audio:
            raise HTTPException(status_code=500, detail="Failed to generate audio response")
        
        # Check if interview ended after this exchange
        interview_ended = interviewer.state.get("interview_ended", False)
        
        return {
            "success": True,
            "user_text": user_text,
            "ai_text": ai_response_text,
            "ai_audio": ai_response_audio,
            "interview_ended": interview_ended,
            "remaining_questions": interviewer.state.get("conversation_limit", 0)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing audio: {str(e)}")

@app.post("/end-interview")
async def end_interview(request: EndInterviewRequest):
    """
    End interview session and cleanup
    """
    try:
        session_id = request.session_id
        
        if session_id not in active_sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Get conversation history before deleting
        interviewer = active_sessions[session_id]
        conversation_history = interviewer.state.get("messages", [])
        
        # Delete session
        del active_sessions[session_id]
        
        return {
            "success": True,
            "message": "Interview ended successfully",
            "conversation_history": conversation_history
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error ending interview: {str(e)}")

@app.get("/session-status/{session_id}")
async def get_session_status(session_id: str):
    """
    Get current session status
    """
    if session_id not in active_sessions:
        return {
            "exists": False,
            "message": "Session not found"
        }
    
    interviewer = active_sessions[session_id]
    
    return {
        "exists": True,
        "interview_ended": interviewer.state.get("interview_ended", False),
        "remaining_questions": interviewer.state.get("conversation_limit", 0),
        "total_messages": len(interviewer.state.get("messages", []))
    }

@app.get("/active-sessions")
async def get_active_sessions():
    """
    Get count of active sessions (for monitoring)
    """
    return {
        "active_sessions": len(active_sessions),
        "session_ids": list(active_sessions.keys())
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)