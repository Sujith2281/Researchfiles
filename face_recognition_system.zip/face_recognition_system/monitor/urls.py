from django.urls import path
from .views import webcam_view

urlpatterns = [
    path('webcam/', webcam_view, name='webcam'),
]
