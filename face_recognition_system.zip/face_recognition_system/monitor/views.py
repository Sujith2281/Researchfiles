import threading
import time
import cv2
import numpy as np
import dlib
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

# Load models for face detection and recognition
def load_models():
    detector = dlib.get_frontal_face_detector()
    predictor = dlib.shape_predictor(r"D:\before_newPC\computer_vision\face_recognition_system\shape_predictor_68_face_landmarks.dat")
    face_rec_model = dlib.face_recognition_model_v1(r"D:\before_newPC\computer_vision\face_recognition_system\dlib_face_recognition_resnet_model_v1.dat")
    return detector, predictor, face_rec_model
# Get the encoding of a detected face
def get_face_encoding(image, shape, face_rec_model):
    face_chip = dlib.get_face_chip(image, shape)
    return np.array(face_rec_model.compute_face_descriptor(face_chip))

# Function to register faces (optional, can be used for initial setup)
def register_face(detector, predictor, face_rec_model, webcam_video_stream, reference_encodings):
    for i in range(10):  # Register 10 faces or a sufficient number
        ret, frame = webcam_video_stream.read()
        if not ret:
            break
        detected_faces = detector(frame, 1)
        print(f"face {i} recognized")
        for face in detected_faces:
            shape = predictor(frame, face)
            encoding = get_face_encoding(frame, shape, face_rec_model)
            reference_encodings.append(encoding)
    return reference_encodings

# Function to monitor faces in the background based on given time
def monitor_faces_in_background(monitoring_time_in_seconds, request, detector, predictor, face_rec_model, webcam_video_stream, reference_encodings):
    start_time = time.time()
    successful_faces_detected = 0
    unknown_faces_count = 0
    no_face_detected = 0
    multiple_faces_duration = 0
    start_multiple_faces_time = None

    while time.time() - start_time < monitoring_time_in_seconds:
        ret, frame = webcam_video_stream.read()
        if not ret:
            break

        detected_faces = detector(frame, 1)
        face_count = len(detected_faces)

        if face_count == 0:
            no_face_detected += 1
        else:
            successful_faces_detected += 1
            if face_count > 1:
                if start_multiple_faces_time is None:
                    start_multiple_faces_time = time.time()
                else:
                    multiple_faces_duration += time.time() - start_multiple_faces_time
                    start_multiple_faces_time = None

            for face in detected_faces:
                shape = predictor(frame, face)
                encoding = get_face_encoding(frame, shape, face_rec_model)

                distances = np.linalg.norm(reference_encodings - encoding, axis=1)
                min_distance = np.min(distances)

                if min_distance > 0.4:  # Unknown face threshold
                    unknown_faces_count += 1
                else:
                    successful_faces_detected += 1

        # Update session variables with the monitoring results
        request.session['successful_faces_detected'] = successful_faces_detected
        request.session['unknown_faces'] = unknown_faces_count
        request.session['No_face_detected'] = no_face_detected
        request.session['multiple_faces_duration'] = multiple_faces_duration
        request.session['total_time'] = time.time() - start_time

        time.sleep(0.5)  # Sleep before the next frame processing

    # Final update to session
    request.session['monitoring'] = False

    # Return the session variables in the response
    # return JsonResponse({
    #     'status': 'Monitoring completed',
    #     'successful_faces_detected': successful_faces_detected,
    #     'unknown_faces': unknown_faces_count,
    #     'No_face_detected': no_face_detected,
    #     'multiple_faces_duration': multiple_faces_duration,
    #     'total_time': time.time() - start_time
    # })
    return successful_faces_detected,unknown_faces_count,no_face_detected,multiple_faces_duration

# View for handling webcam actions
@csrf_exempt
def webcam_view(request):
    if request.method == 'POST':
        action = request.POST.get('action')

        # Get the monitoring time from the POST data (in hours, minutes, and seconds)
        if action == 'start':
            exam_time_hours = int(request.POST.get('hours', 0))
            exam_time_minutes = int(request.POST.get('minutes', 0))
            exam_time_seconds = int(request.POST.get('seconds', 0))
            monitoring_time_in_seconds = (exam_time_hours * 3600) + (exam_time_minutes * 60) + exam_time_seconds

            # Initialize video stream (Webcam)
            webcam_video_stream = cv2.VideoCapture(0)
            detector, predictor, face_rec_model = load_models()
            reference_encodings = []

            # Step 1: Register faces (synchronously)
            reference_encodings = register_face(detector, predictor, face_rec_model, webcam_video_stream, reference_encodings)

            

            # Step 2: Start the background monitoring thread
        
            target=monitor_faces_in_background(monitoring_time_in_seconds, request, detector, predictor, face_rec_model, webcam_video_stream, reference_encodings)
            response_data = {
                'status': 'Monitoring started',
                'successful_faces_detected': target[0],
                'unknown_faces': target[1],
                'No_face_detected': target[2],
                'multiple_faces_duration': target[3],
            }
            print(response_data)

            return JsonResponse(response_data)

        else:
            return JsonResponse({'error': 'Invalid action'})

    # Render the initial page
    return render(request, 'home.html')
